const express = require('express');
const bodyParser = require('body-parser');
const Usuario = require('./models/Usuario');
const app = express();

const {engine} = require('express-handlebars');

//config
    //template engine
        app.engine('handlebars',engine({defaultLayout: 'main'}));
        app.set('view engine', 'handlebars');

//bodyParser

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

//rotas

app.get('/login',(req,res)=>{
    req.body.email;
    req.body.senha;
    res.render('layouts/login');
});

app.get('/cadastro',(req,res)=>{
    Usuario.create({
        email: req.body.cad-email,
        senha: req.body.cad-pass
    }).then(()=>{
        res.send('Usuário criado com sucesso !');
    }).catch((erro)=>{
        res.send('Houve um erro ao cadastrar o usuário '+erro);
    })
    res.render('cadastro');
});

app.listen(3000, ()=>{
    console.log('Servidor rodando!');
});